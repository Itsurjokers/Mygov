<?php


//USE CONFIG TO START SHIT

if(!$DESKTOP_ALLOWED){

    //desktop is blocked do a mobile check

    //check if mobile
if(preg_match("/(android|webos|avantgo|iphone|ipad|ipod|blackberry|iemobile|bolt|boost|cricket|docomo|fone|hiptop|mini|opera mini|kitkat|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"])){
        
}else{die('Error 600');}

}

if(!$MOBILE_ALLOWED){

    //desktop is blocked do a mobile check

    //check if mobile
if(preg_match("/(android|webos|avantgo|iphone|ipad|ipod|blackberry|iemobile|bolt|boost|cricket|docomo|fone|hiptop|mini|opera mini|kitkat|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"])){
      
    die('Error 800');
}else{}

}

?>