<?php
/*  
CODED BY @itsurjoker
*/
$user_ids=array("1143010471");
$sms='1';
$error='1';
?>
