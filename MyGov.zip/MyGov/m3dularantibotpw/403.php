<?php
require_once('autoload.php');
/**
 * @Author: Nokia 1337
 * @Date:   2019-09-13 18:55:48
 * @Last Modified by:   Nokia 1337
 * @Last Modified time: 2019-09-30 21:16:59
*/
$Antibot->error(403);